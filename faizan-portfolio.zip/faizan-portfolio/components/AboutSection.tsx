/**
 * About section describing the developer's background and approach.
 */
export default function AboutSection() {
  return (
    <section id="about" className="py-20">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-6 text-primary">About Me</h2>
        <p className="text-gray-300 leading-relaxed">
          I’m Muhammad Faizan, a full‑stack MERN developer specialising in Next.js. I build clean,
          fast, production‑ready web applications with a focus on clear communication and scalable
          architecture. My experience covers everything from pixel‑perfect UIs to robust back‑end
          APIs and smooth deployments.
        </p>
      </div>
    </section>
  )
}