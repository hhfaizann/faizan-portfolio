/**
 * Contact section with call‑to‑action buttons linking to Upwork and GitHub.
 */
export default function ContactSection() {
  return (
    <section id="contact" className="py-20">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6 text-primary">Get in Touch</h2>
        <p className="text-gray-300 mb-8">
          Interested in working together? Let’s connect — I’m open for freelance projects and
          collaboration.
        </p>
        <div className="flex justify-center space-x-6">
          <a
            href="https://www.upwork.com/freelancers/~01c2c820e2093902c8"
            target="_blank"
            rel="noopener noreferrer"
            className="bg-primary text-white px-6 py-3 rounded-md font-medium hover:bg-blue-700"
          >
            Upwork Profile
          </a>
          <a
            href="https://github.com/hhfaizann"
            target="_blank"
            rel="noopener noreferrer"
            className="border border-primary text-primary px-6 py-3 rounded-md font-medium hover:bg-primary hover:text-white"
          >
            GitHub Profile
          </a>
        </div>
      </div>
    </section>
  )
}