/**
 * Simple footer displaying copyright.
 */
export default function Footer() {
  const year = new Date().getFullYear()
  return (
    <footer className="py-6 bg-gray-900 text-center text-gray-500">
      <p>&copy; {year} Muhammad Faizan. All rights reserved.</p>
    </footer>
  )
}