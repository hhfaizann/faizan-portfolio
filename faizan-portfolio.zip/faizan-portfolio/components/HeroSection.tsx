import Link from 'next/link'

/**
 * Hero section introducing the developer with a call‑to‑action.
 */
export default function HeroSection() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">
          Muhammad Faizan
        </h1>
        <p className="text-lg md:text-2xl text-gray-400 max-w-2xl mx-auto mb-6">
          Full‑Stack MERN Developer. I build production‑ready Next.js/React apps with scalable backends.
        </p>
        <div className="flex justify-center mt-6 space-x-4">
          <Link
            href="#projects"
            className="bg-primary hover:bg-blue-700 text-white px-6 py-3 rounded-md font-medium"
          >
            View Projects
          </Link>
          <Link
            href="#contact"
            className="border border-primary text-primary hover:bg-primary hover:text-white px-6 py-3 rounded-md font-medium"
          >
            Get In Touch
          </Link>
        </div>
      </div>
    </section>
  )
}