"use client";

import { useState, useEffect } from 'react';
import Link from 'next/link';

/**
 * Responsive navigation bar that becomes opaque when scrolled.
 */
export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav
      className={`fixed w-full z-10 transition-colors ${
        scrolled ? 'bg-gray-900/80 backdrop-blur' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
        <Link href="#" className="text-2xl font-bold text-white">
          Faizan
        </Link>
        <div className="hidden md:flex space-x-6">
          <Link href="#about" className="text-gray-300 hover:text-white">
            About
          </Link>
          <Link href="#skills" className="text-gray-300 hover:text-white">
            Skills
          </Link>
          <Link href="#projects" className="text-gray-300 hover:text-white">
            Projects
          </Link>
          <Link href="#services" className="text-gray-300 hover:text-white">
            Services
          </Link>
          <Link href="#contact" className="text-gray-300 hover:text-white">
            Contact
          </Link>
        </div>
      </div>
    </nav>
  );
}