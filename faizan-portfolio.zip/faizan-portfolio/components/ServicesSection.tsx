/**
 * Services section describing offerings for clients.
 */
const services = [
  {
    title: 'Full‑Stack Web Apps',
    description:
      'Custom dashboards, admin panels, portals and internal tools built with the MERN stack.',
  },
  {
    title: 'Next.js Websites & SaaS Frontends',
    description:
      'Modern web apps with lightning‑fast performance and responsive UI using Next.js and React.',
  },
  {
    title: 'Backend & API Development',
    description:
      'REST APIs, authentication, roles/permissions, CRUD operations, pagination and filtering.',
  },
  {
    title: 'Database & Performance',
    description:
      'Schema design, indexing, caching and optimisation with MongoDB and other databases.',
  },
  {
    title: 'Deployment & DevOps',
    description:
      'Deploy apps on Vercel, DigitalOcean or VPS with environment configuration and basic CI.',
  },
  {
    title: 'AI Features',
    description:
      'Integrate AI features like text/voice search, summarisation and more into your web apps.',
  },
]

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-gray-800">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-10 text-primary">Services</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service) => (
            <div
              key={service.title}
              className="bg-gray-700 p-6 rounded-lg shadow-lg hover:shadow-xl transition-shadow"
            >
              <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
              <p className="text-gray-300">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}