/**
 * Skills section showcasing technologies and tools.
 */
const skills = [
  'React',
  'Next.js',
  'Node.js',
  'JavaScript',
  'TypeScript',
  'MongoDB',
  'Express.js',
  'Tailwind CSS',
  'CSS3',
  'HTML5',
  'Git',
  'Deployment Automation',
  'Authentication',
  'AI Integration',
]

export default function SkillsSection() {
  return (
    <section id="skills" className="py-20 bg-gray-800">
      <div className="max-w-5xl mx-auto px-4">
        <h2 className="text-3xl font-bold mb-6 text-primary">Skills &amp; Tools</h2>
        <div className="flex flex-wrap gap-3">
          {skills.map((skill) => (
            <span
              key={skill}
              className="bg-gray-700 text-gray-100 px-3 py-2 rounded-full text-sm"
            >
              {skill}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}