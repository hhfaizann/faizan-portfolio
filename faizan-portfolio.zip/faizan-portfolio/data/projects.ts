export interface Project {
  name: string
  role: string
  description: string
  skills: string[]
  image: string
  demoUrl?: string
  repoUrl?: string
}

/**
 * Portfolio projects to display on the site. Update this list as new projects are added.
 */
export const projects: Project[] = [
  {
    name: 'Proofly',
    role: 'Full‑Stack Developer',
    description:
      'Proofly is a Sales Memory System that records and transcribes sales meetings, extracts key insights and links conversations to CRM deals, preserving deal context for revenue teams.',
    skills: ['JavaScript', 'React', 'MongoDB', 'Deployment Automation'],
    image: '/images/proofly.png',
  },
  {
    name: 'Get The Fit – AI Fashion Co‑Pilot',
    role: 'Full‑Stack Web Developer',
    description:
      'Built an AI fashion co‑pilot that helps users turn social inspiration into purchases by detecting looks, finding similar options and filtering by price, style, material and colour.',
    skills: ['JavaScript', 'TypeScript', 'Node.js', 'MongoDB', 'Continuous Deployment'],
    image: '/images/get-the-fit.png',
  },
]